This folder contains only Frontend related coding tutorials.

Note that `utility/` is the only sub folder that does not contains actual tutorial, but only contains utility code for the coding example.